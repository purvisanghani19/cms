import './App.css';
import { Outlet, Route, Routes } from "react-router";
import { faculty, user, Student } from './Routes/route';
import { useState } from 'react';
import Prorout from './Prorout';
import Login from './Pages/User/Home/Login';



function App() {

  const [isLogin, setIsLogin] = useState(true);

  return (

    <div className='App'>
    <Routes>  
      {isLogin ===  true && faculty.map((faculty)=>{
        return(
        <Route path={faculty.path} element={faculty.element}></Route>
        )
      })}
      {isLogin === false && Student.map((Student)=>{
        return(
        <Route path={Student.path} element={Student.element}></Route>
        )
      })}
      {isLogin === false && user.map((user)=>{
        return(
        <Route path={user.path} element={user.element}></Route>
        )
      })}
    </Routes>
  </div>
  )
}


export default App;
