import React from 'react';
import WithLayout from '../../../components/common/comstudent/Stusidebar';
import './noleave.css';

const Noleave = () => {
    return (
        <>
           <section className="page_no-leave">
  <div className="container">
    <div className="row"> 
    <div className="col-sm-12 no-leave">
    <div className="col-sm-10 col-sm-offset-1  text-center">
    <div className="four_zero_four_bg">
      {/* <h1 className="text-center ">Oopps !!</h1> */}
    </div>
    
    <div className="contant_box_404">
    <h3 className="h2">
    Oopps !! you have not taken any leave yet.
    </h3>
    
    {/* <p>the page you are looking for not avaible!</p> */}
    
    <a href="/Leavestud/Stuleaveform" className="link_404">Add leave</a>
  </div>
    </div>
    </div>
    </div>
  </div>
</section>
        </>
    )
}

export default WithLayout(Noleave);