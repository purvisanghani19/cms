import React from 'react';
import WithLayout from '../../../components/common/comstudent/Stusidebar';

const Viewstudmaterial = () => {
  return (
    <div>Viewstudmaterial</div>
  )
}

export default WithLayout(Viewstudmaterial);