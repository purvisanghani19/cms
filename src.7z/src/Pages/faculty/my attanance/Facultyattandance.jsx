import React from 'react'
import WithLayout from '../../../components/common/comfaculty/Sidebar/SideBar';
import './facultyatt.css';







const Facultyattandance = () => {
  return (
    <>

dcvbnm,
         
    </>
  )
}

export default WithLayout(Facultyattandance);