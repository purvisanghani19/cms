import React from "react";
// import "./result.css";

// import '../../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import WithLayout from "../../../components/common/comstudent/Stusidebar";

const StuResult = () => {
  return (
    <>
    dsfghjkl
    </>
  );
};

export default WithLayout(StuResult);
