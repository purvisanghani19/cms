import React from 'react';
import './attandance.css';
import WithLayout from '../../../components/common/Sidebar/SideBar';

const Attandance = () => {
  return (
   <>
    <div class="container">
		<h1>Attendance</h1>
		<table>
			<tr>
				<th>Subject</th>
				<th>Attendance</th>
			</tr>
			<tr>
				<td>Mathematics</td>
				<td><button class="present">Present</button></td>
			</tr>
			<tr>
				<td>English</td>
				<td><button class="absent">Absent</button></td>
			</tr>
			<tr>
				<td>Science</td>
				<td><button class="present">Present</button></td>
			</tr>
			<tr>
				<td>Social Studies</td>
				<td><button class="present">Present</button></td>
			</tr>
		</table>
	</div>
   </>
  )
}

export default WithLayout(Attandance);
