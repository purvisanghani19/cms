import React from "react";
import "./notice.css";
import WithLayout from "../../../components/common/Sidebar/SideBar";
import { useNavigate } from "react-router";


const Notice = () => {
 
  return (
    <>
      <div class="noti_container">
		<h1>Leave Notice</h1>
		<form>
			<label for="name">Name:</label>
			<input type="text" id="name" name="name" placeholder="Enter your name" required/>
			<label for="email">Email:</label>
			<input type="email" id="email" name="email" placeholder="Enter your email" required/>
			<label for="subject">Subject:</label>
			<input type="text" id="subject" name="subject" placeholder="Enter the subject of your leave" required/>
			<label for="message">Message:</label>
			<textarea id="message" name="message" placeholder="Enter your leave request message" required></textarea>
			<button type="submit">Submit</button>
		</form>
	</div>
    </>
  );
};

export default WithLayout(Notice);
