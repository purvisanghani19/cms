import React from 'react';
import WithLayout from '../../../components/common/Sidebar/SideBar';

const Format = () => {
  return (
   <>
       <div className="col-xl">
        <div className="card mb-4 mt-4 ms-5" style={{ width: "800px" }}>
          <div className="card-body" style={{ height: "600px" }}>
            <form>
              <div className="mb-3">
                <label className="form-label" for="basic-default-fullname">
                  Full Name:
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="basic-default-fullname"
                  placeholder="full name"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" for="basic-default-company">
                  Semester:
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="basic-default-company"
                  placeholder="semester"
                />
              </div>
              <div className="mb-3">
                <label className="form-label" for="basic-default-email">
                  Division:
                </label>
                <div className="input-group input-group-merge">
                  <input
                    type="text"
                    id="basic-default-email"
                    className="form-control"
                    placeholder="division"
                    aria-label="john.doe"
                    aria-describedby="basic-default-email2"
                  />
                </div>
              </div>
              <div className="mb-3"></div>
              <div className="mb-3">
                <label className="form-label" for="basic-default-message">
                  Message:
                </label>

                <input
                  type="text"
                  id="basic-default-email"
                  className="form-control"
                  placeholder="apply for leave"
                  aria-label="john.doe"
                  aria-describedby="basic-default-email2"
                  style={{ height: "200px" }}
                />
              </div>
              <button type="submit" className="btn btn-primary">
                Send
              </button>
            </form>
          </div>
        </div>
      </div>
   </>
  )
}

export default WithLayout(Format);