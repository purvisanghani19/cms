import React, { useState } from "react";
import "./stu.css";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import WithLayout from "../../../components/common/Sidebar/SideBar";
// import { NavLink } from "react-router-dom";

const Student = () => {
  return (
    <>
      <div className="container-xl px-4 mt-4" style={{ marginLeft: "268px",textAlign:"start" }}>
        
    
        <div className="row">
          <div className="col-xl-4" style={{ marginTop: "90px" }}>
            <div className="card mb-4 mb-xl-0">
              <div className="card-header">Profile Picture</div>
              <div className="card-body text-center">
                <img
                  className="img-account-profile rounded-circle mb-2"
                  src="https://t3.ftcdn.net/jpg/03/46/83/96/360_F_346839683_6nAPzbhpSkIpb8pmAwufkC7c5eD7wYws.jpg"
                  alt=""
                />

                <h3>User name</h3>
              </div>
            </div>
          </div>
          <div className="col-xl-8">
            <div className="card mb-4">
              <div className="card-header">Student Details</div>
              <div className="card-body">
                <form>
                
                  <div className="col-md-6">
                    <label className="small mb-1">student id :</label>
                    <p> student id</p>
                  </div>

                  <div className="col-md-6">
                    <label className="small mb-1">First name :</label>
                    <p> student name</p>
                  </div>

                  <div className="col-md-6">
                    <label className="small mb-1">Last name :</label>
                    <p> student name</p>
                  </div>

                    <div className="col-md-6">
                      <label className="small mb-1">Course : </label>
                      <p> student Course</p>
                    </div>
         
                  <div className="col-md-6">
                    <label className="small mb-1">Adress :</label>
                    <p> student adress</p>
                  </div>
                  <div className="col-md-6">
                    <label className="small mb-1">email :</label>
                    <p> student email</p>
                  </div>
             

                    <div className="col-md-6">
                      <label className="small mb-1">Phone number :</label>
                      <p> student phone</p>
                    </div>
                
                  <div className="col-md-6">
                    <label className="small mb-1">Birthday :</label>
                    <p> student birthday</p>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default WithLayout(Student);
